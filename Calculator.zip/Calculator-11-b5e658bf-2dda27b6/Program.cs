﻿Console.WriteLine("Operatie?");
string userInput = Console.ReadLine();
if (userInput == "+")
{
    Console.WriteLine("eerste getal:");
    userInput = Console.ReadLine();
    float userGetal1 = float.Parse(userInput);
    Console.WriteLine("tweede getal:");
    userInput = Console.ReadLine();
    float userGetal2 = float.Parse(userInput);
    Console.WriteLine($"uw getal is {userGetal1 + userGetal2}");
}
else if (userInput == "-")
{
    Console.WriteLine("eerste getal:");
    userInput = Console.ReadLine();
    float userGetal1 = float.Parse(userInput);
    Console.WriteLine("tweede getal");
    userInput = Console.ReadLine();
    float userGetal2 = float.Parse(userInput);
    Console.WriteLine($"uw getal is {userGetal1 - userGetal2}");
}
else if (userInput == "*")
{
    Console.WriteLine("eerste getal:");
    userInput = Console.ReadLine();
    float userGetal1 = float.Parse(userInput);
    Console.WriteLine("tweede getal");
    userInput = Console.ReadLine();
    float userGetal2 = float.Parse(userInput);
    Console.WriteLine($"uw getal is {userGetal1 * userGetal2}");
}
else if (userInput == "/")
{
    Console.WriteLine("eerste getal:");
    userInput = Console.ReadLine();
    float userGetal1 = float.Parse(userInput);
    Console.WriteLine("tweede getal");
    userInput = Console.ReadLine();
    float userGetal2 = float.Parse(userInput);
    if (userGetal2 == 0)
    {
        Console.WriteLine("uw kunt een getal niet delen door 0");
    }
    else
    {
        Console.WriteLine($"uw getal is {userGetal1 / userGetal2}");
    }
}
else if (userInput == "%")
{
    Console.WriteLine("eerste getal:");
    Console.WriteLine("(Hele getalen)");
    userInput = Console.ReadLine();
    int userGetal1 = int.Parse(userInput);
    Console.WriteLine("tweede getal");
    userInput = Console.ReadLine();
    int userGetal2 = int.Parse(userInput);
    if (userGetal2 == 0)
    {
        Console.WriteLine("uw kunt een getal niet delen door 0");
    }
    else
    {
        Console.WriteLine($"uw getal is {userGetal1 % userGetal2}");
    }
}
else
{
    Console.WriteLine("dit is geen geldige operatie");
}
try
{
    Console.WriteLine("nee");
}
catch
{
    Console.WriteLine("ja");
}